const BasePage = require('./base.page')

class HomePage extends BasePage {

    get womenTab(){return $('#block_top_menu a[title="Women"]')}
    get dressesTab(){return $('/ul/a[@title="Dresses"])[2]')}//ul//a[@title='T-shirts'])[2]
    get tShirt(){return $('/ul/a[@title="Dresses"])[2]')}
    open() {        
                super.open('http://automationpractice.com/index.php')
        
            }
}

module.exports = new HomePage();