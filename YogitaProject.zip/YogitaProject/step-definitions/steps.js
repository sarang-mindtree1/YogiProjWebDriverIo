const { Given, When, Then } = require('@cucumber/cucumber')
const HomePage = require( '../pages/home.page')



Given('the user is on Home page', function () {
HomePage.open();
});

When('user can see all the buttons', function () {
    expect((HomePage.womenTab).isDisplayed()).to.be.true;
    expect((HomePage.dressesTab).isDisplayed()).to.be.true;
    expect((HomePage.tShirt).isDisplayed()).to.be.true;
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
});

